phrase_list = {} # Contains the phrases submitted with a timestamp

def process_submit():
    # Place holder response for processing posts. this will simply add a new entry to phrase_list

def return_stats():
    # Place holder response for processing posts. this will simply add a new entry to phrase_list


routes = {
    "/": "Welcome",
    "/submit": process_submit(),
    "/statistics": return_stats(),
    "/stats": return_stats()
}
