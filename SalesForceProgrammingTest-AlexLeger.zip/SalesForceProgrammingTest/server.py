#!/usr/bin/env python3

import time

from http.server import HTTPServer
from server_handler import BasicServer

host_name = 'localhost'
port_number = 8080

if __name__ == '__main__':
    httpd = HTTPServer((host_name, port_number), BasicServer)
    print(time.asctime(), 'Server STARTED at %s:%s' % (host_name, port_number))
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    httpd.server_close()

print(time.asctime(), 'Server STOPPED at %s:%s' % (host_name, port_number))
