#
# Helper functions for working with MFA and Assume-Role in AWS.
#
# The idea is to make MFA and assume role as unintrusive as possible, while
# still providing all their security value (leaked credentials having minimal
# use/longevity).
#
# Include this file in your .bashrc and set a few environment variables and
# aliases to get running.
#
# If you have a yubikey I suggest using yubiauth-cli to remove the interface
# barrier to MFA.
#
# Based (at this point very loosely) on
# https://github.com/EvidentSecurity/MFAonCLI/blob/master/aws-temp-token.sh
#
# Happy Multi-Factor Authing.
#  -- Tim Nicholas


clear_aws_environment() {
    unset AWS_SESSION_TOKEN
    unset AWS_ACCESS_KEY_ID
    unset AWS_SECRET_ACCESS_KEY
    unset AWS_ASSUMED_ROLE_ARN
    unset AWS_ASSUMED_ROLE_ID
    unset AWS_ASSUMED_SESSION_EXPIRATION
    unset AWS_MFA_SESSION_EXPIRATION
}

print_aws_environment() {
    # process defined variables...
    echo AWS_SESSION_TOKEN=$AWS_SESSION_TOKEN
    echo AWS_ACCESS_KEY_ID=$AWS_ACCESS_KEY_ID
    echo AWS_SECRET_ACCESS_KEY=$AWS_SECRET_ACCESS_KEY
    echo AWS_ASSUMED_ROLE_ARN=$AWS_ASSUMED_ROLE_ARN
    echo AWS_ASSUMED_ROLE_ID=$AWS_ASSUMED_ROLE_ID
    echo AWS_ASSUMED_SESSION_EXPIRATION=$AWS_ASSUMED_SESSION_EXPIRATION
    echo AWS_MFA_SESSION_EXPIRATION=$AWS_MFA_SESSION_EXPIRATION
    echo
    # The user defined variables
    echo AWS_MFA_DURATION=$AWS_MFA_DURATION
    echo AWS_ASSUME_DURATION=$AWS_ASSUME_DURATION
}

save_aws_mfa_creds() {
    if [ -n "$AWS_SESSION_TOKEN" -a -n "$AWS_ACCESS_KEY_ID" -a -n "$AWS_SECRET_ACCESS_KEY" ]; then
        export SAVED_AWS_SESSION_TOKEN=$AWS_SESSION_TOKEN
        export SAVED_AWS_ACCESS_KEY_ID=$AWS_ACCESS_KEY_ID
        export SAVED_AWS_SECRET_ACCESS_KEY=$AWS_SECRET_ACCESS_KEY
        export SAVED_AWS_MFA_SESSION_EXPIRATION=$AWS_MFA_SESSION_EXPIRATION
    fi
}

drop_assumed_role() {
    if [ -n "$SAVED_AWS_SESSION_TOKEN" -a -n "$SAVED_AWS_ACCESS_KEY_ID" -a -n "$SAVED_AWS_SECRET_ACCESS_KEY" -a -n "$SAVED_AWS_MFA_SESSION_EXPIRATION" ]; then
        clear_aws_environment
        export AWS_SESSION_TOKEN=$SAVED_AWS_SESSION_TOKEN
        export AWS_ACCESS_KEY_ID=$SAVED_AWS_ACCESS_KEY_ID
        export AWS_SECRET_ACCESS_KEY=$SAVED_AWS_SECRET_ACCESS_KEY
        export AWS_MFA_SESSION_EXPIRATION=$SAVED_AWS_MFA_SESSION_EXPIRATION
        unset SAVED_AWS_SESSION_TOKEN
        unset SAVED_AWS_ACCESS_KEY_ID
        unset SAVED_AWS_SECRET_ACCESS_KEY
        unset SAVED_AWS_MFA_SESSION_EXPIRATION
    fi
}

# override this function to get the code another way (from yubikey for example)
get_aws_mfa_code() {
    local mfa_code
    # prompt on stderr so this can be run in a subshell capturing stdout. 
    vared -ep 'MFA token code: ' mfa_code
    echo $mfa_code
}

get_new_mfa_session() {
    if [ $# -ne 3 ]; then
        echo "Incorrect parameter count!" 1>&2
        echo "Usage: get-new-mfa-function <AWS_CLI_PROFILE> <ARN_OF_MFA> <MFA_TOKEN_CODE>"
        echo "Where:"
        echo "   <AWS_CLI_PROFILE> = aws-cli profile usually in $HOME/.aws/config"
        echo "   <ARN_OF_MFA> = ARN of the virtual MFA assigned to IAM user (arn:aws:iam::012345678901:mfa/user)"
        echo "   <MFA_TOKEN_CODE> = Code from virtual MFA device"
        return 2
    fi

    local AWS_CLI_PROFILE=$1
    local ARN_OF_MFA=$2
    local MFA_TOKEN_CODE=$3

    if [ "${#MFA_TOKEN_CODE}" -ne 6 ]; then
        echo "MFA Token Code should be 6 digits" 1>&2
        return 1
    fi

    if [ -n "$AWS_SESSION_TOKEN" ]; then
        echo "Existing AWS_SESSION_TOKEN detected. Unsetting AWS_ environment variables..." 1>&2
        clear_aws_environment
    fi

    # allow for override of MFA session duration.
    local MFA_DURATION=3600
    if [ -n "$AWS_MFA_DURATION" ]; then
        MFA_DURATION=$AWS_MFA_DURATION
    fi

    if [ -z "$AWS_CLI_PROFILE" ]; then
        echo "AWS_CLI_PROFILE must be defined in the environment." 1>&2
        return 1
    fi

    # get creds and populate the environment.
    eval $(aws --profile "$AWS_CLI_PROFILE" sts get-session-token --duration "$MFA_DURATION" \
        --serial-number "$ARN_OF_MFA" --token-code "$MFA_TOKEN_CODE" --output text \
        | awk '{
            printf("export AWS_ACCESS_KEY_ID=\"%s\"\nexport AWS_MFA_SESSION_EXPIRATION=\"%s\"\nexport AWS_SECRET_ACCESS_KEY=\"%s\"\nexport AWS_SESSION_TOKEN=\"%s\"\n",$2,$3,$4,$5)
            }')

}


assume_aws_role() {
    if [ $# -ne 1 ]; then
        echo "Incorrect parameter count!" 1>&2
        echo "Usage: assume_aws_role <role ARN>"
        return 1
    fi
    local ARN_OF_NEW_ROLE=$1

    local ASSUME_DURATION=5400
    if [ -n "$AWS_ASSUME_DURATION" ]; then
        if [ "$AWS_ASSUME_DURATION" -gt 5400 ]; then
            echo "AWS_ASSUME_DURATION can not be greater than 3600" 1>&2
            echo "Defaulting to 5400" 1>&2
        else
            ASSUME_DURATION=$AWS_ASSUME_DURATION
        fi
    fi

    # reload to the MFA credentials if it appears we already have an assumed
    # role.
    if [ -n "$AWS_ASSUMED_SESSION_EXPIRATION" ]; then
        drop_assumed_role
    fi
    # Save the MFA session credentials (for next time we want to 'reload')
    save_aws_mfa_creds
    if [ "$AWS_TOOLS_DEBUG" == "1" ]; then print_aws_environment; fi
    # Assume the new role.
    local username=$(whoami)
    eval $(aws sts assume-role --role-arn "${ARN_OF_NEW_ROLE}" \
        --role-session-name ${username#*\\}_$(date -u +"%s") \
        --duration-seconds "${ASSUME_DURATION}" --output text | awk \
         '{
            if ( match($1,"CREDENTIALS") ) {
                printf("export AWS_ACCESS_KEY_ID=\"%s\"\nexport AWS_SECRET_ACCESS_KEY=\"%s\"\nexport AWS_SESSION_TOKEN=\"%s\"\nexport AWS_ASSUMED_SESSION_EXPIRATION=\"%s\"\n", $2, $4, $5, $3)
            }
            if ( match($1,"ASSUMEDROLEUSER") ) {
                printf("export AWS_ASSUMED_ROLE_ARN=\"%s\"\nexport AWS_ASSUMED_ROLE_ID=\"%s\"\n", $2, $3)
            }
        }') #end eval

    # Need to save the original ARN for refreshing the role later. The
    # AWS_ASSUMED_ROLE_ARN is different.
    if [ -n "$AWS_ASSUMED_ROLE_ARN" ]; then
        export AWS_ORIG_ROLE_ARN=$ARN_OF_NEW_ROLE
    fi
}

# format a number of seconds as hh:mm:ss
sec2hms() {
    local totalseconds=$1
    if [ $totalseconds -lt 1 ]; then
        echo 00:00:00
        # return failure if expired
        return 1
    else
        local hours=$(($totalseconds/3600))
        local minutes=$(($totalseconds%3600/60))
        local seconds=$(($totalseconds%3600%60))
        printf "%02s:%02s:%02s\n" $hours $minutes $seconds
    fi
}

# takes a datetime as ARG1, returns a number of seconds.
get_seconds_to_datetime() {
    if [ $# -ne 1 ]; then
        echo "Incorrect parameter count!" 1>&2
        echo "Usage: get_seconds_to_datetime <datetime>"
        echo "  Where datetime looks like '2015-10-05T03:05:49Z')"
        return 1
    fi
    local datetime=$1
    echo $(($(date --date="$datetime" +"%s") - $(date +"%s")))
}

refresh_role() {
    if [ -z "$AWS_ORIG_ROLE_ARN" ]; then
        # no role to refresh
        return 0
    fi

    # An hour is the maximum allows, so don't both setting the duration higher
    # even if requested.
    local ASSUME_DURATION=3600
    if [ -n "$AWS_ASSUME_DURATION" ]; then
        if [ "$AWS_ASSUME_DURATION" -le 3600 ]; then
            ASSUME_DURATION=$AWS_ASSUME_DURATION
        fi
    fi

    # Don't attempt to refresh teh session if MFA has expired.
    if [ $(get_seconds_to_datetime $AWS_MFA_SESSION_EXPIRATION) -lt 1 ]; then
        echo 'MFA session expired, no point trying to refresh role' 1>&2
        echo "Role expires in $(sec2hms $(get_seconds_to_datetime $AWS_ASSUMED_SESSION_EXPIRATION))." 1>&2
        return 0
    fi
    echo "refreshing assumed role..." 1>&2
    # Reassume the role. assume_aws_role deals with resetting creds.
    # strip the session name from the ARN. Hopefully this ends up
    # with the same input that was requested previously.
    assume_aws_role ${AWS_ORIG_ROLE_ARN}
}


aws_prompt_info() {
    local mfa_status=$(aws_prompt_status "$AWS_MFA_DURATION" "$AWS_MFA_SESSION_EXPIRATION")
    local assumed_role_status=$(aws_prompt_status "$AWS_ASSUME_DURATION" "$AWS_ASSUMED_SESSION_EXPIRATION")
    if [ -n "$assumed_role_status" ]; then
        echo -ne "M=${mfa_status} R=${assumed_role_status}"
    else
        echo -ne "AWS: M=${mfa_status}"
    fi
}


# E=expired
# hh:mm:ss = time to expiry
# N=none
aws_prompt_status() {
    local maxage=$1
    # in case this isn't set... In which case never colour the output.
    if [ -z "$maxage" ]; then
        maxage=0
    fi
    local datetime=$2
    local _status=''
    if [ -n "$datetime" ]; then
        local seconds=$(get_seconds_to_datetime $datetime)
        if [ $seconds -le 0 ]; then
            _status="E"
        else
            _status=$(sec2hms $seconds)
        fi
        local no_colour="\033[0m"
        local red_colour="\033[31m"
        if [ $seconds -le $(($maxage / 2)) ]; then
            _status=${red_colour}${status}${no_colour}
        fi
     else
        _status='N'
    fi
    echo $_status
}

